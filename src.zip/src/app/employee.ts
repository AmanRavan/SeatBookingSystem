export class Employee{
    employeeId:number;
    employeeName:string;
    emailId:string;
    department:string;
    password:string;
}