export class Admin{
    adminId:number;
    adminName:string;
    mailId:string;
    password:string;
}